const SAVE_ENDPOINT = "http://127.0.0.1:47921/bookmarks";
const LOOKUP_ENDPOINT = "http://127.0.0.1:47921/bookmarks/lookup";
const TAGS_ENDPOINT = "http://127.0.0.1:47921/tags";
const HEALTH_ENDPOINT = "http://127.0.0.1:47921/health";

const saveView = document.getElementById("saveView");
const urlInput = document.getElementById("url");
const urlToggle = document.getElementById("urlToggle");
const urlEditor = document.getElementById("urlEditor");
const domainLabel = document.getElementById("domainLabel");
const faviconImg = document.getElementById("favicon");
const titleInput = document.getElementById("title");
const savedPill = document.getElementById("savedPill");
const tagBox = document.getElementById("tagBox");
const tagInput = document.getElementById("tagInput");
const tagSuggestionsEl = document.getElementById("tagSuggestions");
const saveButton = document.getElementById("save");
const saveLabel = document.getElementById("saveLabel");
const pairingAlert = document.getElementById("pairingAlert");
const pairingAlertLink = document.getElementById("pairingAlertLink");
const saveAlert = document.getElementById("saveAlert");
const saveAlertText = document.getElementById("saveAlertText");
const retryLink = document.getElementById("retryLink");
const settingsBtn = document.getElementById("settingsBtn");
const connectionLink = document.getElementById("connectionLink");
const connectionLabel = document.getElementById("connectionLabel");
const modKey = document.getElementById("modKey");

const connectionView = document.getElementById("connectionView");
const connectionBackBtn = document.getElementById("connectionBackBtn");
const tokenInput = document.getElementById("token");
const saveTokenButton = document.getElementById("saveToken");
const saveTokenLabel = document.getElementById("saveTokenLabel");
const tokenResult = document.getElementById("tokenResult");
const tokenResultText = document.getElementById("tokenResultText");

const settingsView = document.getElementById("settingsView");
const settingsBackBtn = document.getElementById("settingsBackBtn");
const autoSaveToggle = document.getElementById("autoSaveToggle");
const autoCloseToggle = document.getElementById("autoCloseToggle");
const matchThemeToggle = document.getElementById("matchThemeToggle");
const defaultTagsBox = document.getElementById("defaultTagsBox");
const defaultTagsChipInput = document.getElementById("defaultTagsChipInput");
const defaultTagsSuggestionsEl = document.getElementById("defaultTagsSuggestions");

const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

let existingTags = [];
let pendingSaveTimeout = null;
// Whether the current tab already exists in Boomark (found by the lookup endpoint on
// open, or created by a save during this popup's lifetime). Flips the button copy
// from "Boomark it" to "Update" so re-saving reads as the upsert it actually is.
let alreadySaved = false;
// The tab's own already-resolved favicon, captured once in init(). Sent along with
// the save so Boomark can use it instead of its own anonymous fetch, which redirects
// to a login page (with no favicon of its own) for anything that requires sign-in.
let currentFaviconUrl = null;

// --- Tag chips ---------------------------------------------------------
// One reusable chip-input-with-autocomplete component, instantiated once for the
// save view's Tags field and once for Settings' Default Tags field, so both look
// and behave identically instead of the latter being a plain comma-separated input.

function createTagPicker({ box, input, suggestionsEl, getExistingTags, onChange }) {
  let tags = [];
  let activeSuggestionIndex = -1;

  function renderChips() {
    box.querySelectorAll(".chip").forEach((el) => el.remove());
    for (const tag of tags) {
      const chip = document.createElement("span");
      chip.className = "chip";
      chip.textContent = tag;
      const remove = document.createElement("button");
      remove.type = "button";
      remove.setAttribute("aria-label", `Remove ${tag}`);
      remove.innerHTML =
        '<svg viewBox="0 0 8 8" fill="none"><path d="M1 1l6 6M7 1L1 7" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>';
      remove.addEventListener("click", () => removeTag(tag, chip));
      chip.appendChild(remove);
      box.insertBefore(chip, input);
    }
    onChange?.(tags);
  }

  // Removing a chip plays its exit animation first, so neighbors slide over instead
  // of snapping. The data updates immediately; only the DOM removal waits. Under
  // reduced motion the chip just disappears.
  function removeTag(tag, chipEl) {
    tags = tags.filter((t) => t !== tag);
    onChange?.(tags);
    if (reducedMotion) {
      chipEl.remove();
      return;
    }
    chipEl.style.maxWidth = `${chipEl.offsetWidth}px`;
    chipEl.classList.add("removing");
    chipEl.addEventListener("animationend", () => chipEl.remove(), { once: true });
  }

  function addTag(rawName) {
    const name = rawName.trim();
    if (!name) return;
    const isDuplicate = tags.some((t) => t.toLowerCase() === name.toLowerCase());
    if (!isDuplicate) {
      // Prefer the existing tag's canonical casing over whatever was typed.
      const existing = getExistingTags();
      const canonical = existing.find((t) => t.toLowerCase() === name.toLowerCase()) ?? name;
      tags.push(canonical);
      renderChips();
    }
    input.value = "";
    hideSuggestions();
  }

  function matchingTags() {
    const query = input.value.trim().toLowerCase();
    if (!query) return [];
    return getExistingTags().filter(
      (tag) =>
        tag.toLowerCase().includes(query) &&
        !tags.some((selected) => selected.toLowerCase() === tag.toLowerCase())
    );
  }

  function renderSuggestions() {
    const query = input.value.trim();
    const matches = matchingTags().slice(0, 6);
    const exactMatch = matches.some((tag) => tag.toLowerCase() === query.toLowerCase());

    suggestionsEl.innerHTML = "";
    activeSuggestionIndex = -1;

    if (!query) {
      suggestionsEl.classList.remove("show");
      return;
    }

    for (const tag of matches) {
      const option = document.createElement("div");
      option.className = "option";
      option.textContent = tag;
      option.addEventListener("mousedown", (event) => {
        event.preventDefault();
        addTag(tag);
      });
      suggestionsEl.appendChild(option);
    }

    if (!exactMatch) {
      const create = document.createElement("div");
      create.className = "option create";
      create.innerHTML = `Create <strong>"${query.replace(/</g, "&lt;")}"</strong>`;
      create.addEventListener("mousedown", (event) => {
        event.preventDefault();
        addTag(query);
      });
      suggestionsEl.appendChild(create);
    }

    suggestionsEl.classList.toggle("show", suggestionsEl.children.length > 0);
  }

  function hideSuggestions() {
    suggestionsEl.classList.remove("show");
    suggestionsEl.innerHTML = "";
    activeSuggestionIndex = -1;
  }

  function moveSuggestionFocus(delta) {
    const options = [...suggestionsEl.querySelectorAll(".option")];
    if (options.length === 0) return;
    options[activeSuggestionIndex]?.classList.remove("active");
    activeSuggestionIndex = (activeSuggestionIndex + delta + options.length) % options.length;
    options[activeSuggestionIndex].classList.add("active");
  }

  input.addEventListener("input", renderSuggestions);
  input.addEventListener("focus", () => box.classList.add("focused"));
  input.addEventListener("blur", () => {
    box.classList.remove("focused");
    hideSuggestions();
  });
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === ",") {
      // Cmd/Ctrl+Enter is the global save shortcut — let it through to the document
      // handler instead of committing a tag.
      if (event.metaKey || event.ctrlKey) return;
      event.preventDefault();
      const options = [...suggestionsEl.querySelectorAll(".option")];
      const active = options[activeSuggestionIndex];
      if (active) {
        active.dispatchEvent(new Event("mousedown"));
      } else {
        addTag(input.value);
      }
    } else if (event.key === "Backspace" && input.value === "" && tags.length > 0) {
      const lastChip = [...box.querySelectorAll(".chip:not(.removing)")].at(-1);
      const lastTag = tags[tags.length - 1];
      if (lastChip) removeTag(lastTag, lastChip);
    } else if (event.key === "ArrowDown") {
      event.preventDefault();
      moveSuggestionFocus(1);
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      moveSuggestionFocus(-1);
    } else if (event.key === "Escape") {
      hideSuggestions();
    }
  });
  box.addEventListener("click", () => input.focus());

  return {
    getTags: () => [...tags],
    setTags: (newTags) => {
      tags = [...newTags];
      renderChips();
    },
    commitPendingInput: () => {
      if (input.value.trim()) addTag(input.value);
    },
  };
}

// Tag commits/removals only update the local chip list and re-save the whole
// bookmark on every single change (whether creating a brand-new tag or assigning an
// existing one - both go through the same addTag/removeTag path) turned out to be
// unreliable in practice: Boomark's upsert overwrites `tags` wholesale rather than
// merging, so any two of those saves racing (even chained/queued attempts) could still
// land out of order and silently drop a tag depending on exact timing. Sending once,
// from one explicit action (the Save/Update button, or ⌘Enter), is simpler and
// provably correct instead: there's only ever one request in flight for this
// bookmark's tags, carrying whatever's in the box at that moment.
const tagPicker = createTagPicker({
  box: tagBox,
  input: tagInput,
  suggestionsEl: tagSuggestionsEl,
  getExistingTags: () => existingTags,
  onChange: () => markDirty(),
});

const defaultTagsPicker = createTagPicker({
  box: defaultTagsBox,
  input: defaultTagsChipInput,
  suggestionsEl: defaultTagsSuggestionsEl,
  getExistingTags: () => existingTags,
  onChange: (tags) => {
    api.storage.local.set({ defaultTags: tags.join(", ") });
  },
});

// --- Save flow ---------------------------------------------------------

function parseTagString(value) {
  return (value ?? "")
    .split(",")
    .map((tag) => tag.trim())
    .filter(Boolean);
}

function mergeTags(base, extra) {
  const merged = [...base];
  for (const tag of extra) {
    if (!merged.some((existing) => existing.toLowerCase() === tag.toLowerCase())) {
      merged.push(tag);
    }
  }
  return merged;
}

// Only http/https pages can be bookmarked — browser-internal pages (chrome://,
// about:, the new-tab page) would just bounce off Boomark's URL normalizer anyway,
// so say so up front instead of offering a save that can't succeed.
function isSavableUrl(url) {
  return /^https?:\/\//i.test(url ?? "");
}

// The banner now only narrates problems ("info" for unsavable pages, "error" for
// failures) — success lives in the save button itself, which morphs into a green
// checked state. `showRetry` adds a Retry action for "Boomark isn't running" errors.
function setSaveStatus(message, kind, { showRetry = false } = {}) {
  saveAlert.classList.remove("info", "success", "error", "show");
  retryLink.style.display = showRetry ? "inline" : "none";
  if (!message) return;
  saveAlertText.textContent = message;
  saveAlert.classList.add(kind, "show");
}

function setSaveButtonState(state) {
  saveButton.classList.remove("saving", "saved");
  if (state) saveButton.classList.add(state);
  saveButton.disabled = state === "saving";
}

// Editing anything after a successful save drops the button out of its green
// "done" state so it invites the follow-up save (which updates the same bookmark).
function markDirty() {
  if (!saveButton.classList.contains("saved")) return;
  setSaveButtonState(null);
  saveLabel.textContent = alreadySaved ? "Update" : "Boomark it";
}

function setPagePreview(tab) {
  try {
    domainLabel.textContent = new URL(tab.url).hostname;
  } catch {
    domainLabel.textContent = tab.url ?? "";
  }
  if (tab.favIconUrl && /^https?:/.test(tab.favIconUrl)) {
    faviconImg.addEventListener("load", () => faviconImg.classList.add("show"), { once: true });
    faviconImg.src = tab.favIconUrl;
  }
}

// Reflects a bookmark the lookup endpoint found for this tab: its stored title and
// tags (both possibly edited inside Boomark since the original save) become the
// starting point, and the UI switches to update language.
function applyExistingBookmark(existing) {
  alreadySaved = true;
  savedPill.classList.add("show");
  saveLabel.textContent = "Update";
  if (existing.title) titleInput.value = existing.title;
  if (Array.isArray(existing.tags) && existing.tags.length > 0) {
    tagPicker.setTags(existing.tags);
  }
}

async function lookupBookmark(boomarkToken, url) {
  try {
    const response = await fetch(`${LOOKUP_ENDPOINT}?url=${encodeURIComponent(url)}`, {
      headers: { Authorization: `Bearer ${boomarkToken}` },
    });
    const data = await response.json();
    if (response.ok && data.ok && data.found) return data;
  } catch {
    // Older Boomark builds don't have this endpoint; the popup just behaves as before.
  }
  return null;
}

// The chip only claims "Connected" after Boomark actually answered a request — having
// a token in storage proves nothing about whether the app is running right now.
// "checking" is the neutral in-flight state, "offline" means the probe failed.
function setConnectionChip(state) {
  connectionLink.classList.remove("connected", "offline");
  if (state === "connected") {
    connectionLink.classList.add("connected");
    connectionLabel.textContent = "Connected";
  } else if (state === "offline") {
    connectionLink.classList.add("offline");
    connectionLabel.textContent = "Offline";
  } else {
    connectionLabel.textContent = "Checking…";
  }
}

async function refreshPairingState() {
  const { boomarkToken } = await api.storage.local.get("boomarkToken");

  if (!boomarkToken) {
    pairingAlert.classList.add("show");
    connectionLink.classList.remove("show");
    saveButton.disabled = true;
    return;
  }

  pairingAlert.classList.remove("show");
  connectionLink.classList.add("show");
  setConnectionChip("checking");
  saveButton.disabled = false;

  const { matchBoomarkTheme } = await api.storage.local.get("matchBoomarkTheme");
  if (matchBoomarkTheme ?? true) applyLiveTheme(boomarkToken);

  // Doubles as the connectivity probe for the chip. A failure is still non-fatal
  // for the popup itself: the tag box keeps working for typing brand-new tags.
  try {
    const response = await fetch(TAGS_ENDPOINT, {
      headers: { Authorization: `Bearer ${boomarkToken}` },
    });
    const data = await response.json();
    if (response.ok && data.ok) {
      existingTags = data.tags ?? [];
      setConnectionChip("connected");
    } else {
      setConnectionChip("offline");
    }
  } catch {
    setConnectionChip("offline");
  }
}

async function init() {
  // The hint shows the platform's real modifier, not a hardcoded ⌘.
  if (!/mac/i.test(navigator.platform)) modKey.textContent = "Ctrl";

  const [tab] = await api.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    urlInput.value = tab.url ?? "";
    titleInput.value = tab.title ?? "";
    if (tab.favIconUrl && /^https?:/.test(tab.favIconUrl)) currentFaviconUrl = tab.favIconUrl;
    setPagePreview(tab);
  }
  await refreshPairingState();

  if (!isSavableUrl(urlInput.value)) {
    setSaveStatus("This browser page can't be saved to Boomark.", "info");
    saveButton.disabled = true;
    return;
  }

  // Auto-save fires only on this initial popup open — never when navigating back from
  // Settings — and never for a page that's already in Boomark: re-upserting would bump
  // its dateAdded and clobber tags edited inside the app. Instead the popup opens
  // showing what's stored, ready to be updated deliberately.
  const { boomarkToken, autoSave } = await api.storage.local.get(["boomarkToken", "autoSave"]);
  if (boomarkToken) {
    const existing = await lookupBookmark(boomarkToken, urlInput.value);
    if (existing) {
      applyExistingBookmark(existing);
    } else if (autoSave ?? true) {
      save();
    }
  }
  // Tags are the thing worth adding by hand, so they get focus — with auto-save on,
  // the flow is: open popup, page is saved, type tags, ⌘↩ (or the button) to attach them.
  tagInput.focus();
}

async function save() {
  const { boomarkToken, defaultTags, autoCloseAfterSave } = await api.storage.local.get([
    "boomarkToken",
    "defaultTags",
    "autoCloseAfterSave",
  ]);
  if (!boomarkToken || !isSavableUrl(urlInput.value)) return;

  tagPicker.commitPendingInput();
  const tags = mergeTags(tagPicker.getTags(), parseTagString(defaultTags));
  const wasUpdate = alreadySaved;

  setSaveButtonState("saving");
  setSaveStatus("");

  try {
    const response = await fetch(SAVE_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${boomarkToken}`,
      },
      body: JSON.stringify({
        url: urlInput.value,
        title: titleInput.value,
        tags,
        faviconURL: currentFaviconUrl,
      }),
    });
    const data = await response.json();
    if (!response.ok || !data.ok) {
      throw new Error(data.error ?? `Save failed (${response.status})`);
    }
    // A first-time save announces itself with the success banner up top (plus the
    // button going green). The "Already in Boomark" pill is deliberately NOT shown
    // here: it means "this page was in Boomark before you opened the popup", and
    // borrowing it for a fresh save reads as if the save bounced off an existing
    // bookmark. Updates skip the banner too — the pill and the "Updated" button
    // already tell that story. The banner has no auto-hide; it stays up until the
    // popup actually closes.
    alreadySaved = true;
    setConnectionChip("connected");
    setSaveButtonState("saved");
    saveLabel.textContent = wasUpdate ? "Updated" : "Boomarked";
    if (!wasUpdate) setSaveStatus("Saved to Boomark", "success");
    // The toolbar icon flashes a ✓ too — handled by background.js so the flash
    // clears even if this popup closes first.
    try {
      api.runtime.sendMessage({ type: "flash-badge" }).catch?.(() => {});
    } catch {
      // No background page (e.g. converted Safari build without one) — cosmetic only.
    }
    // Stays open by default — the URL was just upserted, so adding tags and saving
    // again here updates that same bookmark rather than creating a duplicate.
    if (autoCloseAfterSave) {
      pendingSaveTimeout = setTimeout(() => window.close(), 900);
    }
  } catch (error) {
    setSaveButtonState(null);
    const unreachable = error.message === "Failed to fetch";
    if (unreachable) setConnectionChip("offline");
    setSaveStatus(
      unreachable ? "Can't reach Boomark. Is it running?" : error.message,
      "error",
      { showRetry: unreachable }
    );
  }
}

// --- Settings and Connection: two separate screens (same popup, no new tab/
// window), each reached directly from its own trigger — the header gear opens
// Settings (behavior/defaults), the pairing warning opens Connection. Neither
// links to the other, so adjusting one never surfaces anything about the other.
// Navigation is a directional slide: forward pushes left, back slides right.

let currentView = saveView;
let navigating = false;

async function transitionTo(next, direction) {
  if (next === currentView || navigating) return;
  // A pending auto-close timer would otherwise keep running in the background and
  // yank the popup shut out from under someone who just navigated to Settings —
  // e.g. to turn Auto-close off in the first place.
  if (pendingSaveTimeout) {
    clearTimeout(pendingSaveTimeout);
    pendingSaveTimeout = null;
  }
  const prev = currentView;
  currentView = next;
  if (reducedMotion) {
    prev.style.display = "none";
    next.style.display = "block";
    return;
  }
  navigating = true;
  const exit = prev.animate(
    [
      { opacity: 1, transform: "translateX(0)" },
      { opacity: 0, transform: `translateX(${-16 * direction}px)` },
    ],
    { duration: 120, easing: "ease-in", fill: "forwards" }
  );
  await exit.finished;
  prev.style.display = "none";
  // Dropping the forwards-fill matters: left in place it would keep this view at
  // opacity 0 forever, overriding the entrance animation next time we come back.
  exit.cancel();
  next.style.display = "block";
  next.animate(
    [
      { opacity: 0, transform: `translateX(${16 * direction}px)` },
      { opacity: 1, transform: "translateX(0)" },
    ],
    { duration: 180, easing: "cubic-bezier(0.2, 0.9, 0.3, 1)" }
  );
  navigating = false;
}

function setTokenResult(message, kind) {
  tokenResultText.textContent = message;
  tokenResult.classList.remove("success", "error", "show");
  if (kind) tokenResult.classList.add(kind, "show");
}

function showSaveView() {
  transitionTo(saveView, -1);
}

async function showConnection() {
  const { boomarkToken } = await api.storage.local.get("boomarkToken");
  tokenInput.value = boomarkToken ?? "";
  setTokenResult("");
  setSaveTokenButtonState(null);
  await transitionTo(connectionView, 1);
  tokenInput.focus();
}

async function showSettings() {
  const stored = await api.storage.local.get([
    "autoSave",
    "autoCloseAfterSave",
    "matchBoomarkTheme",
    "defaultTags",
  ]);
  autoSaveToggle.checked = stored.autoSave ?? true;
  autoCloseToggle.checked = stored.autoCloseAfterSave ?? false;
  matchThemeToggle.checked = stored.matchBoomarkTheme ?? true;
  defaultTagsPicker.setTags(parseTagString(stored.defaultTags));
  transitionTo(settingsView, 1);
}

// Same on/off states as the main Save button (`setSaveButtonState`) - a spinner while
// checking, green with a checkmark once actually confirmed, back to plain otherwise.
function setSaveTokenButtonState(state) {
  saveTokenButton.classList.remove("saving", "saved");
  if (state) saveTokenButton.classList.add(state);
  saveTokenButton.disabled = state === "saving";
  saveTokenLabel.textContent = state === "saved" ? "Connected" : "Save";
}

// Save doubles as the connection test — mirrors how Karakeep's own extension works
// (their Login button validates and persists in one action, no separate "test" step).
// The token only gets written to storage once it's actually confirmed to work.
async function saveToken() {
  const value = tokenInput.value.trim();
  setTokenResult("");
  setSaveTokenButtonState("saving");

  try {
    const response = await fetch(HEALTH_ENDPOINT, {
      headers: { Authorization: `Bearer ${value}` },
    });
    const data = await response.json();
    if (!response.ok || !data.ok) {
      throw new Error(data.error ?? `Failed (${response.status})`);
    }
    await api.storage.local.set({ boomarkToken: value });
    setSaveTokenButtonState("saved");
    setTokenResult("Connected to Boomark", "success");
    await refreshPairingState();
  } catch (error) {
    setSaveTokenButtonState(null);
    setTokenResult(
      error.message === "Failed to fetch" ? "Can't reach Boomark. Is it running?" : error.message,
      "error"
    );
  }
}

autoSaveToggle.addEventListener("change", () => {
  api.storage.local.set({ autoSave: autoSaveToggle.checked });
});
autoCloseToggle.addEventListener("change", () => {
  api.storage.local.set({ autoCloseAfterSave: autoCloseToggle.checked });
});
matchThemeToggle.addEventListener("change", async () => {
  await api.storage.local.set({ matchBoomarkTheme: matchThemeToggle.checked });
  if (matchThemeToggle.checked) {
    const { boomarkToken } = await api.storage.local.get("boomarkToken");
    applyLiveTheme(boomarkToken);
  } else {
    // Drops every inline override applyLiveTheme() set, falling back to the
    // hardcoded Catppuccin values authored in the stylesheet.
    document.documentElement.style.cssText = "";
  }
});
urlToggle.addEventListener("click", () => {
  const open = urlEditor.classList.toggle("open");
  urlToggle.setAttribute("aria-expanded", String(open));
  if (open) urlInput.focus();
});
titleInput.addEventListener("input", markDirty);
urlInput.addEventListener("input", markDirty);
saveButton.addEventListener("click", save);
retryLink.addEventListener("click", save);
settingsBtn.addEventListener("click", showSettings);
pairingAlertLink.addEventListener("click", showConnection);
connectionLink.addEventListener("click", showConnection);
connectionBackBtn.addEventListener("click", showSaveView);
settingsBackBtn.addEventListener("click", () => {
  // Catches a tag that was typed but not yet committed with Enter/comma before
  // leaving — same as save() does for the main Tags field.
  defaultTagsPicker.commitPendingInput();
  showSaveView();
});
saveTokenButton.addEventListener("click", saveToken);

// ⌘/Ctrl+Enter saves from anywhere in the popup — no need to tab to the button.
document.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
    if (currentView === saveView && !saveButton.disabled) {
      event.preventDefault();
      save();
    } else if (currentView === connectionView && !saveTokenButton.disabled) {
      event.preventDefault();
      saveToken();
    }
  }
});

init();
