// Minimal background script with exactly one job: flash a ✓ on the toolbar icon
// after a successful save. It lives here (not in the popup) because auto-close can
// shut the popup before a popup-side timer would get to clear the badge — an event
// worker outlives that by design, and MV3 keeps it alive comfortably past 1.5s.
const api = globalThis.browser ?? globalThis.chrome;

let clearBadgeTimeout = null;

api.runtime.onMessage.addListener((message) => {
  if (message?.type !== "flash-badge") return;
  api.action.setBadgeText({ text: "✓" });
  api.action.setBadgeBackgroundColor({ color: "#40a02b" });
  if (api.action.setBadgeTextColor) api.action.setBadgeTextColor({ color: "#ffffff" });
  if (clearBadgeTimeout) clearTimeout(clearBadgeTimeout);
  clearBadgeTimeout = setTimeout(() => {
    api.action.setBadgeText({ text: "" });
    clearBadgeTimeout = null;
  }, 1500);
});

// A stale ✓ could survive a mid-flash worker shutdown or browser quit — wipe it
// whenever the worker (re)starts so the badge never lies about a save that's long past.
api.action.setBadgeText({ text: "" });
