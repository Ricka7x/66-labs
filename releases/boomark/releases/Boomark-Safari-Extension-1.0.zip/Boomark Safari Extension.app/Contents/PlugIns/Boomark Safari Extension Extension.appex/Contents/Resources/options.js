const HEALTH_ENDPOINT = "http://127.0.0.1:47921/health";

const tokenInput = document.getElementById("token");
const saveButton = document.getElementById("save");
const statusEl = document.getElementById("status");
const statusText = document.getElementById("statusText");

function setStatus(message, kind) {
  statusText.textContent = message;
  statusEl.classList.remove("error", "success", "show");
  if (message) statusEl.classList.add("show");
  if (kind) statusEl.classList.add(kind);
}

async function load() {
  const { boomarkToken } = await api.storage.local.get("boomarkToken");
  if (boomarkToken) tokenInput.value = boomarkToken;
  applyLiveTheme(boomarkToken);
}

// Save doubles as the connection test, same as the popup's settings view — the token
// only gets written to storage once it's actually confirmed to work.
async function save() {
  const value = tokenInput.value.trim();
  setStatus("");
  saveButton.disabled = true;

  try {
    const response = await fetch(HEALTH_ENDPOINT, {
      headers: { Authorization: `Bearer ${value}` },
    });
    const data = await response.json();
    if (!response.ok || !data.ok) {
      throw new Error(data.error ?? `Failed (${response.status})`);
    }
    await api.storage.local.set({ boomarkToken: value });
    setStatus("Connected to Boomark", "success");
    applyLiveTheme(value);
  } catch (error) {
    setStatus(
      error.message === "Failed to fetch" ? "Can't reach Boomark. Is it running?" : error.message,
      "error"
    );
  } finally {
    saveButton.disabled = false;
  }
}

saveButton.addEventListener("click", save);
load();
