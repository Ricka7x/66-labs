# Boomark Browser Extension

Saves the current tab to Boomark from a toolbar popup. Talks to the local HTTP bridge Boomark
runs on `127.0.0.1:47921` while it's open — same one codebase for every browser below,
with a pairing token (Boomark → Settings → General → Browser Extension) as the only setup
step per browser.

Nice-to-knows once paired:

- **⌘⇧S** (Ctrl+Shift+S elsewhere) opens the popup from the keyboard; **⌘↩** inside it
  saves. Rebindable per browser (`chrome://extensions/shortcuts` and equivalents).
- If the current tab is **already in Boomark**, the popup opens showing its stored title and
  tags instead of silently re-saving: the button reads "Update" and auto-save stays out
  of the way. (Needs a Boomark build with the `/bookmarks/lookup` bridge endpoint; against
  an older build the popup just behaves as before.)
- The toolbar icon flashes a **✓** after each successful save. That's `background.js`'s
  only job.

## Chrome, Edge, Brave, Arc

All four are Chromium and load this folder directly, unpacked:

1. Open `chrome://extensions` (or the equivalent `edge://extensions`, `brave://extensions`).
   Arc: `Settings → Extensions → Manage Extensions`, or just open `chrome://extensions` — Arc
   accepts it too.
2. Turn on **Developer mode** (top-right toggle).
3. **Load unpacked** → select this `BrowserExtension` folder.
4. Click the Boomark toolbar icon once, then **Extension settings** → paste the pairing token
   from Boomark's Settings window → **Test Connection**.

## Firefox

Firefox needs a signed `.xpi` for a permanent install; for now, load it temporarily (fine
for personal use, reloads each time Firefox restarts):

1. Open `about:debugging#/runtime/this-firefox`.
2. **Load Temporary Add-on…** → select `manifest.json` inside this folder.
3. Pin the Boomark icon from the toolbar overflow menu, then pair the token as above.

Permanent install (no dev-mode reload needed) requires submitting to
[addons.mozilla.org](https://addons.mozilla.org) for signing — free, but goes through
Mozilla's review. Worth doing once this is working the way you want.

## Safari

Safari doesn't load extension folders directly — it needs the same source repackaged as a
Safari Web Extension, which Apple's converter does in one step:

```sh
xcrun safari-web-extension-converter BrowserExtension --macos-only --project-location <somewhere>
```

That generates an Xcode project with an app + extension target using this exact
`popup.html`/`popup.js`/`options.html`/`options.js`/`manifest.json` — no code changes,
different packaging only. Open the generated project, build and run once to register the
extension, then enable it in Safari → Settings → Extensions. (This is a one-time, local
Xcode step — not something to run unattended, since it scaffolds a new Xcode project on
disk.)

## Publishing to each store

Everything above is a local/personal install. Shipping this so *anyone* can install it
without dev-mode toggles means submitting to each store separately later — Chrome Web
Store, Edge Add-ons, Firefox AMO, and (for Safari) bundling the converted extension inside
a notarized/App-Store build of Boomark itself. Each of those needs your own developer account
(and in Chrome's/Apple's case, a fee), so it's a deliberate follow-up step once you're happy
with how the extension behaves — not something to do sight-unseen.
