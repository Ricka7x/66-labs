// Chrome/Edge/Brave/Arc (MV3) support promise-based `chrome.*` APIs since Chrome 88, and
// Firefox/Safari expose the same shape natively as `browser.*` — so a single-line shim
// covers all five without vendoring the full webextension-polyfill.
const api = globalThis.browser ?? globalThis.chrome;
