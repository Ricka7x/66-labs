const THEME_ENDPOINT = "http://127.0.0.1:47921/theme";

function hexToRgba(hex, alpha) {
  const clean = hex.replace("#", "");
  const full = clean.length >= 6 ? clean : clean.repeat(2).slice(0, 6);
  const r = parseInt(full.slice(0, 2), 16);
  const g = parseInt(full.slice(2, 4), 16);
  const b = parseInt(full.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function applyThemeVariant(colors) {
  if (!colors) return;
  const root = document.documentElement.style;
  if (colors.background) root.setProperty("--base", colors.background);
  if (colors.card) root.setProperty("--mantle", colors.card);
  if (colors.border) root.setProperty("--surface0", colors.border);
  if (colors.text) root.setProperty("--text", colors.text);
  if (colors.subtext) root.setProperty("--subtext0", colors.subtext);
  if (colors.accent) {
    root.setProperty("--mauve", colors.accent);
    root.setProperty("--mauve-glow", hexToRgba(colors.accent, 0.22));
  }
}

// Matches whatever theme is actually selected in Boomark right now (any of its 20
// presets, not just Catppuccin) instead of always hardcoding one look. Falls back
// silently to the built-in Catppuccin CSS if Boomark isn't running or isn't paired yet
// — every call site here is best-effort, never blocking.
async function applyLiveTheme(boomarkToken) {
  if (!boomarkToken) return;
  try {
    const response = await fetch(THEME_ENDPOINT, {
      headers: { Authorization: `Bearer ${boomarkToken}` },
    });
    const data = await response.json();
    if (!response.ok || !data.ok) return;
    const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    applyThemeVariant(isDark ? data.dark : data.light);
  } catch {
    // Non-fatal.
  }
}
